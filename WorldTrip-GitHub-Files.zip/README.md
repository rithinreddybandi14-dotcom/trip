# WorldTrip — Full-stack starter
Created by BANDI RITHIN REDDY.

React + TypeScript + Vite frontend, Express API, Zod validation, and PostgreSQL-ready schema. This is a starter application, not a production-ready booking service. Real flight/hotel booking, maps, currency feeds, email delivery, and Sri Karthikeya Smart Visas integrations require authorized APIs, credentials, and end-to-end tests.

## Run
- Node.js 20+
- `npm install`
- Copy `.env.example` to `.env` and edit values
- `npm run dev`
- Vite frontend: `http://localhost:5173`; API: `http://localhost:4000`

## GitHub
Upload the entire folder structure to the repository root. Do not upload only `package.json`. Never commit `.env` or API keys.

## Before production
Configure PostgreSQL/migrations, real authentication, email provider, licensed destination inventory, maps/currency/hotel/flight APIs, verified payment webhooks, rate limiting, security headers, privacy/terms/cancellation policies, and end-to-end tests.
