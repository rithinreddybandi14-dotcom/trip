# WorldTrip production checklist

- [ ] Configure managed PostgreSQL and migration workflow; remove in-memory enquiry storage.
- [ ] Add tested authentication (secure sessions or reputable identity provider), password reset, email verification, MFA for admins.
- [ ] Add role-based authorization to every admin API route; audit logs and rate limiting.
- [ ] Add secure headers, CSRF strategy, request-size limits, input validation, dependency scanning, and backups.
- [ ] Import 1,000+ licensed/verified destination records with source attribution and refresh policy.
- [ ] Obtain and test authorized maps, currency, accommodation, flight and email provider credentials.
- [ ] Confirm whether Sri Karthikeya Smart Visas offers a partner API; if not, use a clearly labeled enquiry handoff.
- [ ] Add verified provider availability, timestamps, currencies, fees, taxes, and cancellation terms.
- [ ] Implement payment provider webhooks and server-side verification before recording any payment.
- [ ] Write jurisdiction-appropriate privacy, terms, refund/cancellation, and booking support policies.
- [ ] Add unit, API, browser, accessibility, mobile, and security tests.
- [ ] Configure production environment variables and custom domain; test HTTPS and monitoring.
- [ ] Do not present demo destinations as verified inventory or enquiries as confirmed bookings.
