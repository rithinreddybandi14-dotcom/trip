import express from 'express';
import cors from 'cors';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';

const app = express();
const port = Number(process.env.PORT || 4000);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));

const destinations = [
  { id: 1, name: 'Bali', country: 'Indonesia', category: 'Island escape', image: 'photo-1537996194471-e657df975ab4', description: 'Temple mornings, emerald rice terraces and slow coastal days.' },
  { id: 2, name: 'Swiss Alps', country: 'Switzerland', category: 'Mountain retreat', image: 'photo-1531366936337-7c912a4589a7', description: 'Alpine villages, scenic rail journeys and crisp mountain air.' },
  { id: 3, name: 'Jaipur', country: 'India', category: 'Culture & heritage', image: 'photo-1599661046827-dacff0c0f09a', description: 'Rose-hued palaces, vibrant bazaars and unforgettable cuisine.' },
  { id: 4, name: 'Amalfi Coast', country: 'Italy', category: 'Coastal getaway', image: 'photo-1533105079780-92b9be482077', description: 'Cliffside villages, blue water and Mediterranean lunches.' },
  { id: 5, name: 'Kyoto', country: 'Japan', category: 'Culture & temples', image: 'photo-1493976040374-85c8e12f0c0e', description: 'Quiet shrines, garden paths and seasonal traditions.' },
  { id: 6, name: 'Maldives', country: 'Maldives', category: 'Beach & resort', image: 'photo-1514282401047-d79a71a590e8', description: 'Clear lagoons, overwater stays and restorative island time.' }
];

const enquirySchema = z.object({
  type: z.enum(['trip-planning', 'visa', 'flight', 'hotel']).default('trip-planning'),
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  origin: z.string().trim().min(2).max(150),
  destination: z.string().trim().min(2).max(150),
  days: z.number().int().min(1).max(90),
  travellers: z.number().int().min(1).max(30),
  budget: z.number().min(0).max(100000000)
});

// Temporary in-memory storage: enquiries reset when this process restarts.
// Replace with PostgreSQL before production.
const enquiries: Array<{ reference: string; createdAt: string; [key: string]: unknown }> = [];

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'WorldTrip API', productionReady: false }));
app.get('/api/destinations', (_req, res) => res.json(destinations));
app.post('/api/enquiries', (req, res) => {
  const parsed = enquirySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Please check the enquiry fields.', details: parsed.error.flatten().fieldErrors });
  const reference = `WT-${randomUUID().slice(0, 8).toUpperCase()}`;
  enquiries.push({ ...parsed.data, reference, createdAt: new Date().toISOString() });
  return res.status(201).json({ reference, status: 'received', message: 'Enquiry received. This is not a booking confirmation.' });
});

app.listen(port, '0.0.0.0', () => console.log(`WorldTrip API listening on ${port}`));
