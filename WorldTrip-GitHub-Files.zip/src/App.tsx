import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Compass, MapPin, Menu, Plane, Search, ShieldCheck, Sparkles, X } from 'lucide-react';

type Destination = {
  id: number; name: string; country: string; category: string;
  image: string; description: string;
};

const curated: Destination[] = [
  { id: 1, name: 'Bali', country: 'Indonesia', category: 'Island escape', image: 'photo-1537996194471-e657df975ab4', description: 'Temple mornings, emerald rice terraces and slow coastal days.' },
  { id: 2, name: 'Swiss Alps', country: 'Switzerland', category: 'Mountain retreat', image: 'photo-1531366936337-7c912a4589a7', description: 'Alpine villages, scenic rail journeys and crisp mountain air.' },
  { id: 3, name: 'Jaipur', country: 'India', category: 'Culture & heritage', image: 'photo-1599661046827-dacff0c0f09a', description: 'Rose-hued palaces, vibrant bazaars and unforgettable cuisine.' },
  { id: 4, name: 'Amalfi Coast', country: 'Italy', category: 'Coastal getaway', image: 'photo-1533105079780-92b9be482077', description: 'Cliffside villages, blue water and Mediterranean lunches.' },
  { id: 5, name: 'Kyoto', country: 'Japan', category: 'Culture & temples', image: 'photo-1493976040374-85c8e12f0c0e', description: 'Quiet shrines, garden paths and seasonal traditions.' },
  { id: 6, name: 'Maldives', country: 'Maldives', category: 'Beach & resort', image: 'photo-1514282401047-d79a71a590e8', description: 'Clear lagoons, overwater stays and restorative island time.' }
];
const imageUrl = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1100&q=85`;

export default function App() {
  const [destinations, setDestinations] = useState<Destination[]>(curated);
  const [search, setSearch] = useState('');
  const [origin, setOrigin] = useState('Vijayawada, India');
  const [destination, setDestination] = useState('');
  const [days, setDays] = useState(5);
  const [travellers, setTravellers] = useState(2);
  const [budget, setBudget] = useState(50000);
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');

  useEffect(() => {
    fetch('/api/destinations')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (Array.isArray(data) && data.length) setDestinations(data); })
      .catch(() => {});
  }, []);

  const filtered = useMemo(() => destinations.filter(d =>
    `${d.name} ${d.country} ${d.category}`.toLowerCase().includes(search.toLowerCase())
  ), [destinations, search]);

  async function submitEnquiry(e: React.FormEvent) {
    e.preventDefault();
    setMessage('');
    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'trip-planning', name: 'Website visitor', email, origin, destination, days, travellers, budget })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not submit enquiry');
      setMessage(`Enquiry received. Reference: ${data.reference}. This is a planning enquiry, not a booking.`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to send enquiry. Please try again.');
    }
  }

  return <div className="app-shell">
    <header className="navbar">
      <a className="brand" href="#"><span className="brand-mark"><Compass size={22}/></span><span>WorldTrip<small>TRAVEL, THOUGHTFULLY</small></span></a>
      <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X/> : <Menu/>}</button>
      <nav className={menuOpen ? 'nav-links open' : 'nav-links'}>
        <a href="#destinations" onClick={() => setMenuOpen(false)}>Discover</a>
        <a href="#planner" onClick={() => setMenuOpen(false)}>Trip planner</a>
        <a href="#services" onClick={() => setMenuOpen(false)}>Our services</a>
        <button className="login-btn" onClick={() => { setAuthMode('login'); setAuthOpen(true); }}>Log in</button>
        <button className="nav-cta" onClick={() => { setAuthMode('register'); setAuthOpen(true); }}>Create account <ArrowRight size={16}/></button>
      </nav>
    </header>

    <main>
      <section className="hero">
        <div className="hero-photo" />
        <div className="hero-content">
          <div className="eyebrow"><Sparkles size={15}/> YOUR NEXT CHAPTER STARTS HERE</div>
          <h1>The world is wide.<br/><em>Go beyond</em> ordinary.</h1>
          <p>Meaningful journeys, remarkable stays, and every little detail thoughtfully brought together.</p>
          <div className="hero-actions"><a className="primary-btn" href="#planner">Plan your journey <ArrowRight size={17}/></a><a className="text-btn" href="#destinations">Explore destinations <span>↗</span></a></div>
          <div className="trust-row"><span><ShieldCheck size={16}/> Thoughtful planning</span><span><MapPin size={16}/> Around the world</span></div>
        </div>
        <div className="hero-caption"><span>01 / 06</span><span>Find your kind of somewhere</span></div>
      </section>

      <section className="search-wrap" id="planner">
        <div className="section-kicker">LET'S MAKE IT HAPPEN</div>
        <div className="planner-head"><div><h2>Your journey, <em>your way.</em></h2><p>Start with a place, and we’ll help you shape the rest.</p></div><span className="planner-icon"><Plane/></span></div>
        <form className="planner-form" onSubmit={submitEnquiry}>
          <label><span>Starting from</span><input value={origin} onChange={e => setOrigin(e.target.value)} required placeholder="City or airport"/></label>
          <label><span>Where to?</span><input value={destination} onChange={e => setDestination(e.target.value)} required placeholder="Destination, country"/></label>
          <label><span>Days</span><input type="number" min="1" max="90" value={days} onChange={e => setDays(Number(e.target.value))} required/></label>
          <label><span>Travellers</span><input type="number" min="1" max="30" value={travellers} onChange={e => setTravellers(Number(e.target.value))} required/></label>
          <label><span>Budget (₹)</span><input type="number" min="0" value={budget} onChange={e => setBudget(Number(e.target.value))} required/></label>
          <label className="email-field"><span>Email for reply</span><input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="you@example.com"/></label>
          <button className="primary-btn planner-submit" type="submit">Request a plan <ArrowRight size={17}/></button>
        </form>
        {message && <p className="form-message" role="status">{message}</p>}
        <p className="disclaimer">Planning enquiry only. Live prices, availability and bookings are not claimed by this starter.</p>
      </section>

      <section className="destinations section-pad" id="destinations">
        <div className="section-kicker">THE WORLD, CURATED</div>
        <div className="section-heading"><div><h2>Places that <em>stay with you.</em></h2><p>Find a little inspiration for wherever you want to go next.</p></div><div className="destination-search"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search destinations"/></div></div>
        <div className="destination-grid">{filtered.map((d, i) => <article className={`destination-card card-${i % 3}`} key={d.id}>
          <img src={d.image.startsWith('photo-') ? imageUrl(d.image) : d.image} alt={`${d.name}, ${d.country}`} loading="lazy"/>
          <div className="card-overlay"><span className="card-category">{d.category}</span><h3>{d.name}</h3><p><MapPin size={14}/>{d.country}</p><span className="card-description">{d.description}</span></div>
        </article>)}</div>
        {filtered.length === 0 && <p className="empty-state">No matching destinations yet. Try a country, city or travel style.</p>}
        <p className="data-note">Starter destination records are illustrative. Connect a licensed destination data source for 1,000+ verified records.</p>
      </section>

      <section className="services section-pad" id="services">
        <div className="section-kicker">A BETTER WAY TO GET THERE</div><h2>More than a destination.<br/><em>A whole experience.</em></h2>
        <div className="service-grid">
          <div><span className="service-number">01</span><MapPin/><h3>Thoughtful itineraries</h3><p>Shape your route around your dates, pace, interests and budget.</p></div>
          <div><span className="service-number">02</span><ShieldCheck/><h3>Visa assistance</h3><p>Send an enquiry to Sri Karthikeya Smart Visas for human follow-up.</p><a href="https://srikarthikeyasmartvisas.com/" target="_blank" rel="noreferrer">Visit Sri Karthikeya Smart Visas ↗</a></div>
          <div><span className="service-number">03</span><Plane/><h3>Flight & stay enquiries</h3><p>Request assistance without fabricated fares, tickets or confirmations.</p><a href="#planner">Start an enquiry ↗</a></div>
        </div>
      </section>
      <section className="closing"><div className="section-kicker">YOUR WORLD IS WAITING</div><h2>Somewhere wonderful<br/>is closer than you think.</h2><a className="primary-btn" href="#planner">Start planning <ArrowRight size={17}/></a></section>
    </main>

    <footer><a className="brand footer-brand" href="#"><span className="brand-mark"><Compass size={21}/></span><span>WorldTrip<small>TRAVEL, THOUGHTFULLY</small></span></a>
      <div className="footer-links"><a href="#services">About</a><a href="#planner">Contact</a><a href="#privacy">Privacy Policy</a><a href="#terms">Terms</a><a href="#cancellation">Cancellation Policy</a><a href="#planner">Booking Support</a></div>
      <p>© {new Date().getFullYear()} WorldTrip. Created by <strong>BANDI RITHIN REDDY</strong>.</p>
      <p className="footer-note">Policies and live booking integrations must be completed before production launch.</p>
    </footer>

    {authOpen && <div className="modal-backdrop" role="presentation" onClick={() => setAuthOpen(false)}><div className="auth-modal" role="dialog" aria-modal="true" aria-label={authMode === 'login' ? 'Log in' : 'Create account'} onClick={e => e.stopPropagation()}>
      <button className="modal-close" onClick={() => setAuthOpen(false)} aria-label="Close"><X/></button><span className="brand-mark"><Compass/></span>
      <div className="section-kicker">WELCOME TO WORLDTRIP</div><h2>{authMode === 'login' ? 'Welcome back.' : 'Your next journey awaits.'}</h2>
      <p>Account interface preview: secure registration and login must be connected to an authentication provider before production.</p>
      <button className="primary-btn full-width" onClick={() => { setAuthOpen(false); document.getElementById('planner')?.scrollIntoView({ behavior: 'smooth' }); }}>Continue with trip enquiry <ArrowRight size={17}/></button>
      <button className="switch-auth" onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}>{authMode === 'login' ? 'New to WorldTrip? Create account' : 'Already have an account? Log in'}</button>
    </div></div>}
  </div>;
}
